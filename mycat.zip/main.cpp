#include <iostream>
#include <stdlib.h>
#include <fstream>
#include <string>
#include <ctype.h>

using namespace std;

void print_help();
void print_single_file(char *file_name, bool a);

int main(int argc, char *argv[])
{
    if (argc == 1)
    {
        cerr << "Error: no arguments provided, exit" << endl;
        exit(1);
    }

    for (int i = 1; i < argc; ++i)
    {
        if (string(argv[i]) == "-h" || string(argv[i]) == "--help")
        {
            print_help();
            return 0;
        }
    }

    bool a = false;
    for (int i = 1; i < argc; ++i)
    {
        if (!a && string(argv[i]) == "-A")
        {
            a = true;
            break;
        }
    }
    for (int i = 1; i < argc; ++i)
    {
        if (string(argv[i]) != "-A")
            print_single_file(argv[i], a);
    }

    exit (0);
    return 0;
}

void print_help()
{
    cout << "help:" << endl
         << "mycat [-h|--help] [-A] <file1> <file2> ... <fileN>" << endl;
}

void print_single_file(char *file_name, bool a)
{
    string line;
    ifstream file(file_name);
    if (file.is_open())
    {
        while (getline(file, line))
        {
            for (int i = 0; i < line.length(); ++i)
            {
                if (!a)
                {
                    cout << line[i];
                }
                else
                {
                    if (isspace(line[i]) && !isprint(line[i]))
                    {
                        printf("\\x%02x", line[i]);
                    }
                    else
                    {
                        cout << line[i];
                    }
                }
            }
            cout << endl;
        }
        file.close();
    }

    else
    {
        cerr << "Error: unable to open file: " << file_name << endl;
        exit(2);
    }
}